
##BLACKJACK

Blackjack, also known as twenty-one, where players dealt two cards, reaching a final score higher than the dealer without exceeding 21 win, is a comparing card game between usually several players and a dealer.

##Game Table
  * Players are each dealt two cards (face up). The dealer is also dealt two cards, one up (exposed) and one down (hidden)
  * Players are allowed to draw additional cars (HIT) or not draw (Stand) when the sum of the cards values is not exceeding 21.
  * Once all the players have completed their hands, the dealer then reveals the hidden card and must hit until the cards total 17 or more points.
Points Calculation
  * Ace means 1 or 11 points
  * King, Queen, Jack are all worth ten
  * Other cards is their pip value (2 through 10)
Blackjack
  * Get 21 points on the player’s first two card (called a “blackjack”), then players receive 1.5x of the bet. (1.5 to 1)
Bust
  * When player’s hand exceeds 21 points, the player loses his bet.
Push
  * If the player and dealer have the same total, it’s called a push.
Stand
  * Take no more cards. For example, when player or dealer’s hand is more than 17 points, they may choose to stay.
Hit
  * Take another card from the dealer.
Surrender
  * When the player surrenders, the house takes half the player's bet and returns the other half to the player (only available as first decision of a hand)
Insurance 
  * If the dealer’s upcard is an ace, the player is offered the option of taking “insurance”, the amount of which is half the size of player’s original bet.
  * When the dealer has blackjack, it pays 2:1 (meaning that the player receives two dollars for every dollar bet) 
  * When the dealer does not have blackjack, the player loses the insurance bet.
Even Money
  * When dealer’s upcard is an ace, before player buying an insurance, Even Money is offered to a player with blackjack. In case the dealer has a blackjack, the player will push on the original bet and get a 2 to 1 payout on the even money side bet. In case the player does not choose Even Money, and the dealer has a blackjack, it’s a push.

##Double Down
  * The player is allowed to increase the initial bet by up to 100% in exchange for committing to stand after receiving exactly one more card. If the player has a black jack, double down is not allowed.
 
##Split
 
* The player is allowed to increase the initial bet by up to 100% in exchange for committing to stand after receiving exactly one more card. 

